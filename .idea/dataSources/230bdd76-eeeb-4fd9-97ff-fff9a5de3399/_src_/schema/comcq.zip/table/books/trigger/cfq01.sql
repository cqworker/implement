CREATE TRIGGER cfq01
BEFORE INSERT ON books
FOR EACH ROW
  BEGIN
 update users
 set name = 1 ;
END;
