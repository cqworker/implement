CREATE PROCEDURE sp2()
  BEGIN
set @a=3;
select *from users;
END;
