CREATE PROCEDURE ccgc01()
  BEGIN
 #Routine body goes here...
 declare n bigint;
 set n = 201121029684;
 while n <= 201121029694
 do
 insert into users(id) values(n);
 set n = n + 1;
 end while;
END;
